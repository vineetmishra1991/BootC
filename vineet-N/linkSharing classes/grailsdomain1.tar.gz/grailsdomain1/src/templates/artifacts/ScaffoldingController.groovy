@artifact.package@class @artifact.name@ {
    static scaffold = true
}
