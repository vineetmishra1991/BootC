package com.poc.domainclass1

class Task {

    String name
    Employee assignedTo
    Employee assignedBy
    Date dateCreated
    Date lastUpdated

    static constraints = {
    }
}
