package com.poc.domainclass1

class Engine {
    static belongsTo = [car: Car]
    static constraints = {
    }
}
