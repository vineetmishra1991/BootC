package apackage

/**
 * Created with IntelliJ IDEA.
 * User: mohit
 * Date: 9/14/12
 * Time: 11:51 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FooService {
    public Foo getFoo(String name, int age)

}