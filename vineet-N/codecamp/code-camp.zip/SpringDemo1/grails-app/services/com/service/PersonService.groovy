package com.service

class PersonService {

    public String serviceMethod(String s) {

        return s
    }
}
