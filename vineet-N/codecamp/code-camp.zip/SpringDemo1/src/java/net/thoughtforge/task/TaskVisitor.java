package net.thoughtforge.task;

public interface TaskVisitor {

	void visit(Task task);
}
