package apackage

/**
 * Created with IntelliJ IDEA.
 * User: mohit
 * Date: 9/14/12
 * Time: 8:44 PM
 * To change this template use File | Settings | File Templates.
 */
class Foo {
    String name
    int age

    public Foo(){

    }
    Foo(String name, int age) {
        this.name = name
        this.age = age
    }
}
