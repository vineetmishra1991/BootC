package apackage

/**
 * Created with IntelliJ IDEA.
 * User: mohit
 * Date: 9/11/12
 * Time: 10:42 PM
 * To change this template use File | Settings | File Templates.
 */
interface LoggerDataBean {
    String getData(String abc);
}
