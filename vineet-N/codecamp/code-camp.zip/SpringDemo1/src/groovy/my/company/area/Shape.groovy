package my.company.area

 interface Shape
{

    public String draw();


}
