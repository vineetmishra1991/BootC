package com.test

class LogException {

    String message
    String data
    String exception

    static constraints = {
    }
}
